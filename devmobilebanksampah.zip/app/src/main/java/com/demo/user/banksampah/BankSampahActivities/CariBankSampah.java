package com.demo.user.banksampah.BankSampahActivities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.demo.user.banksampah.R;

public class CariBankSampah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cari_bank_sampah);
    }
}
